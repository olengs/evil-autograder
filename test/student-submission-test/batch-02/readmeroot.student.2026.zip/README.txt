Test README beside the enclosing student folder.
