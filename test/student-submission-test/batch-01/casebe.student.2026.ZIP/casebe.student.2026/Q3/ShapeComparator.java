/*
 * Name: Fixture Student
 * Email ID: casebe.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
