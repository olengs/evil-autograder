/*
 * Name: Fixture Student
 * Email ID: caseaf.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
