/*
 * Name: Fixture Student
 * Email ID: casebr.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
