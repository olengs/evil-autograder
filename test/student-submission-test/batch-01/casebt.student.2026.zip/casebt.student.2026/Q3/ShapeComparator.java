/*
 * Name: Fixture Student
 * Email ID: casebt.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
