/*
 * Name: Fixture Student
 * Email ID: casebi.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
