/*
 * Name: Fixture Student
 * Email ID: casebm.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}

// STUDENT_HELPER_MARKER_WS04
