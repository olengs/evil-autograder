/*
 * Name: Fixture Student
 * Email ID: casea.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
