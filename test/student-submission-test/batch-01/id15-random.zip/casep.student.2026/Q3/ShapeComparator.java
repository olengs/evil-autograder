/*
 * Name: Fixture Student
 * Email ID: alternate.folderpriority.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
