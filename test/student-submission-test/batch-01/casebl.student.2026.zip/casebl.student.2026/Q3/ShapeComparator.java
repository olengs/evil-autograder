/*
 * Name: Fixture Student
 * Email ID: casebl.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
