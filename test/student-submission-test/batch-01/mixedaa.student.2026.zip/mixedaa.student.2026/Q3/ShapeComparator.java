/*
 * Name: Fixture Student
 * Email ID: mixedaa.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
