/*
 * Name: Fixture Student
 * Email ID: CASEAR.STUDENT.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
