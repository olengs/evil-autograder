/*
 * Name: Fixture Student
 * Email ID: casebu.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
