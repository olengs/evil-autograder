/*
 * Email ID: caseaq.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
