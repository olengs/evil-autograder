/*
 * Name: Fixture Student
 * Email ID: casev.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
