/*
 * Name: Fixture Student
 * Email ID: caseae.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
