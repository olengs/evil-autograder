/*
 * Name: Fixture Student
 * Email ID: casebc.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
