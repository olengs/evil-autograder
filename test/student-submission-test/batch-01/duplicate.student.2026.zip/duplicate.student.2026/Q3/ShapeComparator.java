/*
 * Name: Fixture Student
 * Email ID: duplicate.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
