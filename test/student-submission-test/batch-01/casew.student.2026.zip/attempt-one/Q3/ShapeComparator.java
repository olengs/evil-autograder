/*
 * Name: Fixture Student
 * Email ID: casew.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
