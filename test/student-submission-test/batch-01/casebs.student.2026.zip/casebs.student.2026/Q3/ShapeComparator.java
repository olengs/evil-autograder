/*
 * Name: Fixture Student
 * Email ID: casebs.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
