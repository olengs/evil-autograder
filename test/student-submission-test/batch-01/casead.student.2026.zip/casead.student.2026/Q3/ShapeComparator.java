/*
 * Name: Fixture Student
 * Email ID: casead.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
