import java.util.*;   

public class ShapeComparator{

    
}
