/*
 * Name: Fixture Student
 * Email ID: davidfixture.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
