/*
 * Name: Fixture Student
 * Email ID: caseah.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
