/*
 * Name: Fixture Student
 * Email ID: caseaj.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
