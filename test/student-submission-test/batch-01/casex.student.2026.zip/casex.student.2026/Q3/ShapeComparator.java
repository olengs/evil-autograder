/*
 * Name: Fixture Student
 * Email ID: casex.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
