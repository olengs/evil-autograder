/*
 * Name: Fixture Student
 * Email ID: caseat.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
