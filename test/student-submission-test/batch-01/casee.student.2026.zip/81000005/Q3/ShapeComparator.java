/*
 * Name: Fixture Student
 * Email ID: casee.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
