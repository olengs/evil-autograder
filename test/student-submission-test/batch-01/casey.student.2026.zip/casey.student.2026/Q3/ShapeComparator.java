/*
 * Name: Fixture Student
 * Email ID: casey.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
