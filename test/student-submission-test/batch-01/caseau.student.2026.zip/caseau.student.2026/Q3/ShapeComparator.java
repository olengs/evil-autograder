/*
 * Name: Fixture Student
 * Email ID: caseau.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
