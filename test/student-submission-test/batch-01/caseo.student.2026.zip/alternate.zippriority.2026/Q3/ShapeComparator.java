/*
 * Name: Fixture Student
 * Email ID: alternate.zippriority.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
