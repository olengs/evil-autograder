/*
 * Name: Fixture Student
 * Email ID: casec.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
