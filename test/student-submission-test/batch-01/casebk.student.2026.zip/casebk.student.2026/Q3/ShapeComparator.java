/*
 * Name: Fixture Student
 * Email ID: casebk.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
