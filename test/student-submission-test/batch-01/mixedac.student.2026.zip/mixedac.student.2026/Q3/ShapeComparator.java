/*
 * Name: Fixture Student
 * Email ID: mixedac.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
