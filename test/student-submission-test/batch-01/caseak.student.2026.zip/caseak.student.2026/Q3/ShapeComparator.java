/*
 * Name: Fixture Student
 * Email ID: caseak.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
