/*
 * Name: Fixture Student
 * Email ID: CASEH.STUDENT.2026@school.edu
 */

import java.util.*;   

public class ShapeComparator{

    
}
