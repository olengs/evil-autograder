/*
 * Name: Fixture Student
 */

import java.util.*;   

public class ShapeComparator{

    
}
