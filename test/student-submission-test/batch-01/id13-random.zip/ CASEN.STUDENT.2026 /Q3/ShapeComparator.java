/*
 * Name: Fixture Student
 * Email ID: casen.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
