/*
 * Name: Fixture Student
 * Email ID: caseac.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
