/*
 * Name: Fixture Student
 * Email ID: casebq.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
