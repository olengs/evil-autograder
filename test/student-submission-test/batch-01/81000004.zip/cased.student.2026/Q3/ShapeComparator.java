/*
 * Name: Fixture Student
 * Email ID: cased.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
