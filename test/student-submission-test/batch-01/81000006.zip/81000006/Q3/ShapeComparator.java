/*
 * Name: Fixture Student
 * Email ID: casef.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
