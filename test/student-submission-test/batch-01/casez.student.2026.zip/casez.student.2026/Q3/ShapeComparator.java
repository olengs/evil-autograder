/*
 * Name: Fixture Student
 * Email ID: casez.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
