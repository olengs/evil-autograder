/*
 * Name: Fixture Student
 * Email ID: caseag.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
