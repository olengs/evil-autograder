/*
 * Name: Fixture Student
 * Email ID: casem.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
