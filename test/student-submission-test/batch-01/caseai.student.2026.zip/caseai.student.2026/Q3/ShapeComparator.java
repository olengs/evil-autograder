/*
 * Name: Fixture Student
 * Email ID: caseai.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
