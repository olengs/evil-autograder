/*
 * Name: Fixture Student
 * Email ID: caseb.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
