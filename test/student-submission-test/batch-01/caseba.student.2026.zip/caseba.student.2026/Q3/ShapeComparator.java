/*
 * Name: Fixture Student
 * Email ID: caseba.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
