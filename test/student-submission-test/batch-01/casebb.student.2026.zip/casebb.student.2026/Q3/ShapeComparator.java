/*
 * Name: Fixture Student
 * Email ID: casebb.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
