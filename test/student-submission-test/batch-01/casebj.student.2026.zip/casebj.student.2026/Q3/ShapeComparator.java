/*
 * Name: Fixture Student
 * Email ID: casebj.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
