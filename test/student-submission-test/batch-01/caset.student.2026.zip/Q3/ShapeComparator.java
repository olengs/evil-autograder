/*
 * Name: Fixture Student
 * Email ID: caset.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
