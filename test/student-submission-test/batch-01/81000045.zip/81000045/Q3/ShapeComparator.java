/*
 * Name: Fixture Student
 * Email ID: caseas.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
