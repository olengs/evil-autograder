// Name: Fixture Student
// Email: caseam.student.2026

import java.util.*;   

public class ShapeComparator{

    
}
