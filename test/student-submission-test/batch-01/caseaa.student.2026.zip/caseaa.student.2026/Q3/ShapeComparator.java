/*
 * Name: Fixture Student
 * Email ID: caseaa.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
