/*
 * Name : Fixture Student
 * Email ID : caseal.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
