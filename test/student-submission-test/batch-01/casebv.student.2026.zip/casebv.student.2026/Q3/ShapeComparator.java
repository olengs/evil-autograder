/*
 * Name: Fixture Student
 * Email ID: casebv.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
