/*
 * Name: Fixture Student
 * Email ID: caseu.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
