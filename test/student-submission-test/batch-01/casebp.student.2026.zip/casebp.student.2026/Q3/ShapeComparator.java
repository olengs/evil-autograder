/*
 * Name: Fixture Student
 * Email ID: casebp.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
