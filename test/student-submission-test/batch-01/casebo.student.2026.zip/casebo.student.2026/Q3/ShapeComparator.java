/*
 * Name: Fixture Student
 * Email ID: casebo.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
