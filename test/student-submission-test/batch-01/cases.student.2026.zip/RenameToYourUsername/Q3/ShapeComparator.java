/*
 * Name: Fixture Student
 * Email ID: cases.student.2026
 */

import java.util.*;   

public class ShapeComparator{

    
}
