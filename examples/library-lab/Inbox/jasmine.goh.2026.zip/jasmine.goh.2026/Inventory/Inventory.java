// Name: Jasmine Goh
// Email: jasmine.goh.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        System.out.print("x".repeat(3 * 1024 * 1024)); return 0;
    }
}
