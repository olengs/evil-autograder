// Name: Dylan Ali
// Email: dylan.ali.2026
public class WrongName {
    public static int totalAvailable(int[] quantities) {
        int total = 0; for (int q : quantities) if (q > 0) total += q; return total;
    }
}
