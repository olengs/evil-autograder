// Name: Dylan Ali
// Email: dylan.ali.2026
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
