// Name: Hannah Lim
// Email: hannah.lim.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        throw new IllegalArgumentException("sample exception");
    }
}
