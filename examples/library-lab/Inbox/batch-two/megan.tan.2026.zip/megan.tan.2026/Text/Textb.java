// Name: Megan Tan
// Email: megan.tan.2026
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
