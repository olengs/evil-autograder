// Name:
// Email:
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
