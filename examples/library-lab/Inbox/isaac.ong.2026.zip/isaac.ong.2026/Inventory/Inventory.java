// Name: Isaac Ong
// Email: isaac.ong.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        System.exit(1); return 0;
    }
}
