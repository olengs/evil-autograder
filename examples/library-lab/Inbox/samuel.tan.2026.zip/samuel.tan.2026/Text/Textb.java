// Name: Samuel Tan
// Email: samuel.tan.2026
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
