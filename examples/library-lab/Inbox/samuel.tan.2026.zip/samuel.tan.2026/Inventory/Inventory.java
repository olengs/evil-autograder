// Name: Samuel Tan
// Email: samuel.tan.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        int total = 0; for (int q : quantities) if (q > 0) total += q; return total;
    }
}
