/*
 * Name: Rachel Ali
 * Email ID: rachel.ali.2026
 */
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
