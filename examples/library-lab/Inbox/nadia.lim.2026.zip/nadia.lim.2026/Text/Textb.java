// Name: Nadia Lim
// Email: nadia.lim.2026
public class Textb {
    public static String reverse(String text) {
        return text;
    }
}
