// Name: Lydia Tan
// Email: lydia.tan.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        return -1;
    }
}
