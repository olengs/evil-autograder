// Name: Farah Ali
// Email: farah.ali.2026
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
