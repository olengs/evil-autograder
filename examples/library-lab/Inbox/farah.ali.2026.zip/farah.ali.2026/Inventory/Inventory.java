// Name: Farah Ali
// Email: farah.ali.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        if (quantities.length == 0) return 0; while (true) { Thread.onSpinWait(); }
    }
}
