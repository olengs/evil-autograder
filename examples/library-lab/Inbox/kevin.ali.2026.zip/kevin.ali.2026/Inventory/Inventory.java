// Name: Kevin Ali
// Email: kevin.ali.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        System.err.print("x".repeat(3 * 1024 * 1024)); return 0;
    }
}
