// Name: Brandon Ong
// Email: brandon.ong.2026
public class Texta {
    public static int countVowels(String text) {
        int count = 0; for (char c : text.toCharArray()) if ("aeiouAEIOU".indexOf(c) >= 0) count++; return count;
    }
}
