// Name: Evelyn Tan
// Email: evelyn.tan.2026
public class Inventory {
    public static int differentMethod(int[] quantities) {
        int total = 0; for (int q : quantities) if (q > 0) total += q; return total;
    }
}
