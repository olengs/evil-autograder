// Name: Clara Lim
// Email: clara.lim.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        int total = 0; for (int q : quantities) total += q; return total;
    }
}
