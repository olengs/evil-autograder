// Name: Clara Lim
// Email: clara.lim.2026
public class Textb {
    public static String reverse(String text) {
        return text;
    }
}
