// Name: Clara Lim
// Email: clara.lim.2026
public class Texta {
    public static int countVowels(String text) {
        int count = 0; for (char c : text.toCharArray()) if ("aeiou".indexOf(c) >= 0) count++; return count;
    }
}
