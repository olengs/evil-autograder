// Name: Emma Goh
// Email: emma.goh.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        return ;
    }
}
