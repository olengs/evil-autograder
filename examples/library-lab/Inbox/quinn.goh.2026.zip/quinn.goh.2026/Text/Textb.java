// Name: Quinn Goh
// Email: quinn.goh.2026
public class Textb {
    public static String reverse(String text) {
        return new StringBuilder(text).reverse().toString();
    }
}
