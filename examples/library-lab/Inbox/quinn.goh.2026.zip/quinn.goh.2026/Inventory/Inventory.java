﻿// Name: Quinn Goh
// Email: quinn.goh.2026
public class Inventory {
    public static int totalAvailable(int[] quantities) {
        int total = 0; for (int q : quantities) if (q > 0) total += q; return total;
    }
}
